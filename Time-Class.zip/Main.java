/*
Name: Connie Lee
Class: CS111B Java
Assignment: Time Class
Description: Asks user what time it is now, displays the current time, then asks the user ohw many meetings they have and what time each meeting is. Finally, they display what times their meetings are later today and when their last meeting is or displays a message saying they have no more meetings. 
*/

import java.util.Scanner;

class Main
{
  public static void main(String args[])
  {
    Scanner scan = new Scanner(System.in);
    String timeString;
    int numMeetings;
    
    System.out.print("What time is it now? ");
    timeString = scan.nextLine();
    Time.setCurTime(timeString);

    System.out.print("Current time: ");
    Time.showCurTime();
    System.out.println();

    System.out.print("How many meetings do/did you have today? ");
    numMeetings = scan.nextInt();
    scan.nextLine(); // dispose of newline character

    Time[] time = new Time[numMeetings];
    Time laterTime;

    for(int i = 0; i < numMeetings; i++) // goes through each of the indexes
    {
      System.out.print("What time is meeting # " + (i + 1) + " ");
      timeString = scan.next();
      time[i] = new Time(timeString); // storing it into time array
    }

    System.out.print("Here are the times for your meetings that are later today: \n");

    for(int i = 0; i < numMeetings; i++) 
    // still going through the times for the meetings 
    {
      if(time[i].isLaterToday()) // if it's later today
      {
        laterTime = time[i]; // store the time into laterTime variable
        System.out.print(time[i]); // print out the times that are later today
      }
    }

    Time lastMeetingTime = time[0];
    for(Time meetingTimes: time) // goes through the array that was created from the user 
    {
      if(meetingTimes.compareTo(lastMeetingTime) > 0) 
      // if it's greater than 0, then it notices that the comparsion is later
      {
        lastMeetingTime = meetingTimes; 
        // stores whatever those later times are into "lastMeetingTime"
      }
    }
    System.out.print("\nYour last meeting of the day is at " + lastMeetingTime); 
    // prints out the later meetings that the user still needs to go to 

  }
}

/*
Sample Output #1:
What time is it now? 14:00
Current time: 14:00
How many meetings do/did you have today? 3
What time is meeting # 1 2:00
What time is meeting # 2 16:00
What time is meeting # 3 6:00
Here are the times for your meetings that are later today: 
16:00
Your last meeting of the day is at 16:00

Sample Output #2:
What time is it now? 16:00
Current time: 16:00
How many meetings do/did you have today? 3
What time is meeting # 1 1:00
What time is meeting # 2 3:00
What time is meeting # 3 6:00
Here are the times for your meetings that are later today: 

Your last meeting of the day is at 06:00

*/
